pub use fretcat_plugin;

pub use fretcat_plugin::nih_plug;