#[no_mangle]
pub fn process_sample(sample: f32) -> f32 {
    sample * 10.0
}
