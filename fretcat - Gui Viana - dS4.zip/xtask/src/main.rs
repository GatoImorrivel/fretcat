fn main() -> nih_plug_xtask::Result<()> {
    nih_plug_xtask::main()
}
